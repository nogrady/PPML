# Distributed Differentially Private PCA
We have implemented a distributed differentially private PCA algorithm, in where the data are horizontally partitioned. The repo contains certain libraies and ongoing experiments.
